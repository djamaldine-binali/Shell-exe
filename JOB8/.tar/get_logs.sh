last djamal | grep djamal | wc -l | cat > Backup/number_connection-$(date "+%d-%m-%Y-%H:%M" ).log &&

 tar -czvf $log.tar ./$log
